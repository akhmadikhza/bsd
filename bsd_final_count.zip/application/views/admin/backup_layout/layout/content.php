<?php
//load data view yang telah di set

if ($isi) {
	$this->load->view($isi);
}
