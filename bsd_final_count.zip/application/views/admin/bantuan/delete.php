<a href="<?= base_url('admin/bantuan/delete/') . $bantuan['id_bantuan']; ?>" class="btn btn-danger btn-sm tombol-hapus">
    <i class="fa fa-trash"></i> Delete</a>